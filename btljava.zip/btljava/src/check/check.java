/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package check;

import javax.swing.JOptionPane;

/**
 *
 * @author nhanm
 */
public class check {

    public check() {
    }
    
      public static boolean check(String n) {
        if (n == null || n.length() == 0) {
            return false;
        }
        return true;
    }
          
}
 
    
    

