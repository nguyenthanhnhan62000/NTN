/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empty;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author nhanm
 */
public class Hoadon {
    Quanao qa= new Quanao();
    
    private String mhd;
    private String mqa;
    private int slban;
    private int thanhgia;
    private String mnv;
    private LocalDate ngaythangnam;

    public Hoadon() {
    }

    public Hoadon(String mhd, String mqa, int slban, int thanhgia, String mnv,LocalDate ngaythangnam) {
        this.mhd = mhd;
        this.mqa = mqa;
        this.slban = slban;
        this.thanhgia = thanhgia;
        this.mnv = mnv;
        this.ngaythangnam = ngaythangnam;
    }

    /*public Hoadon(String mhd, String mqa, Integer slban, Integer thanhgia, String mnv, LocalDate ngaythangnam) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/

    public void setQa(Quanao qa) {
        this.qa = qa;
    }

    public void setMhd(String mhd) {
        this.mhd = mhd;
    }

    public void setMqa(String mqa) {
        this.mqa = mqa;
    }

    public void setSlban(int slban) {
        this.slban = slban;
    }

    public void setThanhgia(int thanhgia) {
        this.thanhgia = thanhgia;
    }

    public void setMnv(String mnv) {
        this.mnv = mnv;
    }
    
    public void setNgayThangNam(LocalDate ngaythangnam) {
        this.ngaythangnam = ngaythangnam;
    }

    public Quanao getQa() {
        return qa;
    }

    public String getMhd() {
        return mhd;
    }

    public String getMqa() {
        return mqa;
    }

    public int getSlban() {
        return slban;
    }

    public int getThanhgia() {
        return thanhgia;
    }

    public String getMnv() {
        return mnv;
    }

    public LocalDate getNgayThangNam(){
        return ngaythangnam;
    }
   
    
     public Object[] toArray(){
        return  new Object[]{mhd,mqa,slban,thanhgia,mnv, ngaythangnam};
    }
   
}
