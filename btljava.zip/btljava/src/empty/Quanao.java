/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empty;

import java.util.logging.Logger;

/**
 *
 * @author nhanm
 */
public class Quanao {
    
    private String mqa;
    private String size;
    private String theloai ;
    private int  gia;
    private int slton;

    public Quanao() {
    }

    public Quanao(String mqa, String size, String theloai, int gia, int slton) {
        this.mqa = mqa;
        this.size = size;
        this.theloai = theloai;
        this.gia = gia;
        this.slton = slton;
    }

    public void setMqa(String mqa) {
        this.mqa = mqa;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setTheloai(String theloai) {
        this.theloai = theloai;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public void setSlton(int slton) {
        this.slton = slton;
    }
   
    public String getMqa() {
        return mqa;
    }

    public String getSize() {
        return size;
    }

    public String getTheloai() {
        return theloai;
    }

    public int getGia() {
        return gia;
    }

    public int getSlton() {
        return slton;
    }

    

    

    
    
    public Object[] toArray(){
        return  new Object[]{mqa,size,theloai,gia,slton};
    }
      
    
}
