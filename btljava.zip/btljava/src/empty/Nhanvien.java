/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empty;

/**
 *
 * @author nhanm
 */
public class Nhanvien {
    
    private String MNV;
    private String TNV;
    private int SDT;
    private int CMND;

    public Nhanvien() {
    }

    public Nhanvien(String MNV, String TNV, int SDT, int CMND) {
        this.MNV = MNV;
        this.TNV = TNV;
        this.SDT = SDT;
        this.CMND = CMND;
    }

    public void setMNV(String MNV) {
        this.MNV = MNV;
    }

    public void setTNV(String TNV) {
        this.TNV = TNV;
    }

    public void setSDT(int SDT) {
        this.SDT = SDT;
    }

    public void setCMND(int CMND) {
        this.CMND = CMND;
    }
    
    public String getMNV() {
        return MNV;
    }

    public String getTNV() {
        return TNV;
    }

    public int getSDT() {
        return SDT;
    }

    public int getCMND() {
        return CMND;
    }

    
     public Object[] toArray(){
        return  new Object[]{MNV,TNV,SDT,CMND};
    }
    
    
}
