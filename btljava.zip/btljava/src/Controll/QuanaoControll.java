/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controll;

import ConnectDataBase.DBconnect;
import empty.Hoadon;
import empty.Quanao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nhanm
 */
public class QuanaoControll {


     public ArrayList<Quanao> getAll(){
        ArrayList<Quanao> list = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("select *from tbl_QLQA");
                rs = ps.executeQuery();
                //                
//                PS = DBconnect.cnn.prepareStatement("select *from tbl_HOADON");
//                RS= PS.executeQuery();
                //                
                list = new ArrayList<Quanao>();
                while (rs.next() )             
                     {
                    Quanao k = new Quanao();
                    k.setMqa(rs.getString(1));
                    k.setSize(rs.getString(2));
                    k.setTheloai(rs.getString(3));
                    k.setGia(rs.getInt(4));   
                    k.setSlton(rs.getInt(5));
                    
                    
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                DBconnect.close(ps, rs);
            }

        }
        return list;
    }
     public Quanao addNew(Quanao quanao) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("INSERT INTO tbl_QLQA values (?,?,?,?,?)");
                ps.setString(1, quanao.getMqa());
                ps.setString(2, quanao.getSize());
                ps.setString(3, quanao.getTheloai());
                ps.setInt(4, quanao.getGia());
                ps.setInt(5, quanao.getSlton());
                int row = ps.executeUpdate();
                if (row < 1) {
                    quanao = null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                quanao = null;
            }finally{
                DBconnect.close(ps);
            }
        }
        return quanao;
    }
     public void deleteQuanao(String mqa) throws SQLException, ClassNotFoundException{
         
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            ps = DBconnect.cnn.prepareStatement("delete from tbl_QLQA where MQA = ?");
            ps.setString(1, mqa);
            ps.executeUpdate();
            DBconnect.close();
        }
    }
     public Quanao updateByMqa(Quanao q) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("update tbl_QLQA set SIZE = ?,LOAI = ?,GIA= ?, SLTON= ? where  MQA= ?");
                    
                ps.setString(1, q.getSize());
                ps.setString(2, q.getTheloai());
                ps.setInt(3, q.getGia());
                ps.setInt(4, q.getSlton());
                ps.setString(5, q.getMqa());
                
                
                int row = ps.executeUpdate();
                if (row < 1) {
                    q = null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                q = null;
            }finally{
                DBconnect.close();
            }
        }
        return q;
    }
     public ArrayList<Quanao> findByMqa(String mqa) {
       ArrayList<Quanao> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_QLQA where MQA = ?");
                psCheck.setString(1, mqa);
                rs = psCheck.executeQuery();
                list = new ArrayList<Quanao>();
                while (rs.next()) {
                    Quanao k = new Quanao();
                    k.setMqa(rs.getString(1));
                    k.setSize(rs.getString(2));
                      k.setTheloai(rs.getString(3));
                        k.setGia(rs.getInt(4));
                        k.setSlton(rs.getInt(5));
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(QuanaoControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     public ArrayList<Quanao> findByKInd(String theloai) {
       ArrayList<Quanao> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_QLQA where LOAI = ?");
                psCheck.setString(1, theloai);
                rs = psCheck.executeQuery();
                list = new ArrayList<Quanao>();
                while (rs.next()) {
                    Quanao k = new Quanao();
                    k.setMqa(rs.getString(1));
                    k.setSize(rs.getString(2));
                      k.setTheloai(rs.getString(3));
                        k.setGia(rs.getInt(4));
                        k.setSlton(rs.getInt(5));

                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(QuanaoControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     
     
         
         
     
         
        
     
     
     public boolean updateslt (String mqa, int slm) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("update tbl_QLQA set SLTON= ? where  MQA= ? ");
                ps.setInt(1, slm);
                ps.setString(2, mqa); 
               
                int row = ps.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
               
            }finally{
                DBconnect.close();
            }
        }
         return false;
     }
     
     
     public ArrayList<Quanao> getTruyenMQA(String mqa) {
           ArrayList<Quanao> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_QLQA where MQA = ?");
                psCheck.setString(1, mqa);
                rs = psCheck.executeQuery();
                list = new ArrayList<Quanao>();
                while (rs.next()) {
                    Quanao k = new Quanao();
                    k.setMqa(rs.getString(1));
                    k.setSize(rs.getString(2));
                      k.setTheloai(rs.getString(3));
                        k.setGia(rs.getInt(4));
                        k.setSlton(rs.getInt(5));
                    
                   
                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(HoadonControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }

   
     
      
    
      
    
}
