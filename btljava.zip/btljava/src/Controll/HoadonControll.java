/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controll;

import ConnectDataBase.DBconnect;
import empty.Hoadon;
import empty.Quanao;
import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nhanm
 */
public class HoadonControll {
 
    public ArrayList<Hoadon> getAll(){
        ArrayList<Hoadon> list = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("select *from tbl_HOADON");
                rs = ps.executeQuery();
                list = new ArrayList<Hoadon>();
                while (rs.next()) {
                    Hoadon k = new Hoadon();

                    k.setMhd(rs.getString(1));
                    k.setMqa(rs.getString(2));
                    k.setSlban(rs.getInt(3));
                    k.setThanhgia(rs.getInt(4));
                    k.setMnv(rs.getString(5));
                    k.setNgayThangNam(rs.getDate(6).toLocalDate());
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                DBconnect.close(ps, rs);
            }

        }
        return list;
    }
     public Hoadon addNew(Hoadon hoadon) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("INSERT INTO tbl_HOADON values (?,?,?,?,?,?)");
                ps.setString(1, hoadon.getMhd());
                ps.setString(2, hoadon.getMqa());
                ps.setInt(3, hoadon.getSlban());
                ps.setInt(4, hoadon.getThanhgia());
                ps.setString(5, hoadon.getMnv());
                ps.setString(6,hoadon.getNgayThangNam().toString());
                int row = ps.executeUpdate();
                if (row < 1) {
                    hoadon = null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                hoadon = null;
            }finally{
                DBconnect.close(ps);
            }
        }
        return hoadon;
    }
     public void deleteHoadon(String mhd) throws SQLException, ClassNotFoundException{
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            ps = DBconnect.cnn.prepareStatement("delete from tbl_HOADON where MHD = ?");
            ps.setString(1, mhd);
            ps.executeUpdate();
            DBconnect.close();
        }
    }
     public Hoadon updateByID(Hoadon q) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("update tbl_HOADON set MQA = ?,SLBAN = ?,THANHGIA= ?,MNV=? where  MHD= ?");
                    
                ps.setString(1, q.getMqa());
                ps.setInt(2, q.getSlban());
                ps.setInt(3, q.getThanhgia());
                ps.setString(4, q.getMnv());
                ps.setString(5, q.getMhd());
               
               
                
                int row = ps.executeUpdate();
                if (row < 1) {
                    q = null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                q = null;
            }finally{
                DBconnect.close();
            }
        }
        return q;
    }
     public ArrayList<Hoadon> getTruyenMQA(String mqa) {
        ArrayList<Hoadon> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_HOADON where MQA = ?");
                psCheck.setString(1, mqa);
                rs = psCheck.executeQuery();
                list = new ArrayList<Hoadon>();
                while (rs.next()) {
                    Hoadon k = new Hoadon();
                    k.setMhd(rs.getString(1));
                    k.setMqa(rs.getString(2));
                    k.setSlban(rs.getInt(3));
                    k.setThanhgia(rs.getInt(4));
                    k.setMnv(rs.getString(5));
                    k.setNgayThangNam(rs.getDate(6).toLocalDate());
                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(HoadonControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     public ArrayList<Hoadon> getTruyenMHD(String mhd) {
        ArrayList<Hoadon> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_HOADON where MHD = ?");
                psCheck.setString(1, mhd);
                rs = psCheck.executeQuery();
                list = new ArrayList<Hoadon>();
                while (rs.next()) {
                    Hoadon k = new Hoadon();
                    k.setMhd(rs.getString(1));
                    k.setMqa(rs.getString(2));
                    k.setSlban(rs.getInt(3));
                    k.setThanhgia(rs.getInt(4));
                    k.setMnv(rs.getString(5));
                    k.setNgayThangNam(rs.getDate(6).toLocalDate());
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(HoadonControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     public ArrayList<Hoadon> getTruyenMNV(String mnv) {
        ArrayList<Hoadon> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_HOADON where MNV = ?");
                psCheck.setString(1, mnv);
                rs = psCheck.executeQuery();
                list = new ArrayList<Hoadon>();
                while (rs.next()) {
                    Hoadon k = new Hoadon();
                    k.setMhd(rs.getString(1));
                    k.setMqa(rs.getString(2));
                    k.setSlban(rs.getInt(3));
                    k.setThanhgia(rs.getInt(4));
                    k.setMnv(rs.getString(5));
                    k.setNgayThangNam(rs.getDate(6).toLocalDate());
            
                    list.add(k);
                }
            } catch (SQLException ex) {
                Logger.getLogger(HoadonControll.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     
//     public ArrayList<Hoadon> getTruyenslb(int slb ) {
//           ArrayList<Hoadon> list = null;
//        PreparedStatement psCheck = null;
//        ResultSet rs = null;
//        if (DBconnect.open()) {
//            try {
//                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_HOADON where SLB = ?");
//                psCheck.setInt(1, slb);
//                rs = psCheck.executeQuery();
//                list = new ArrayList<Hoadon>();
//                while (rs.next()) {
//                    Hoadon k = new Hoadon();
//                     k.setMhd(rs.getString(1));
//                    k.setCode(rs.getString(2));
//                    k.setSlb(rs.getInt(3));
//                    k.setTg(rs.getInt(4));
//                   
//                    list.add(k);
//                }
//            } catch (SQLException ex) {
//                Logger.getLogger(HoadonControll.class.getName()).log(Level.SEVERE, null, ex);
//            }finally{
//                DBconnect.close(psCheck, rs);
//            }
//            
//        }
//        return list;
//    }
//     
     
}
