/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controll;

import ConnectDataBase.DBconnect;

import empty.Nhanvien;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author nhanm
 */
public class NhanvienControll {
   
    public ArrayList<Nhanvien> getAll(){
        ArrayList<Nhanvien> list = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("select *from tbl_NHANVIEN");
                rs = ps.executeQuery();
                list = new ArrayList<Nhanvien>();
                while (rs.next()) {
                    Nhanvien k = new Nhanvien();

                    k.setMNV(rs.getString(1));
                    k.setTNV(rs.getString(2));
                    k.setSDT(rs.getInt(3));
                    k.setCMND(rs.getInt(4));
                    list.add(k);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                DBconnect.close(ps, rs);
            }

        }
        return list;
    }
     public Nhanvien addNew(Nhanvien nhanvien) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("INSERT INTO tbl_NHANVIEN values (?,?,?,?)");
                ps.setString(1, nhanvien.getMNV());
                ps.setString(2, nhanvien.getTNV());
                ps.setInt(3, nhanvien.getSDT());
                ps.setInt(4, nhanvien.getCMND());
                int row = ps.executeUpdate();
                if (row < 1) {
                    nhanvien= null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                nhanvien = null;
            }finally{
                DBconnect.close(ps);
            }
        }
        return nhanvien;
    }
     public void deleteNhanvien(String mnv) throws SQLException, ClassNotFoundException{
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            ps = DBconnect.cnn.prepareStatement("delete from tbl_NHANVIEN where MNV = ?");
            ps.setString(1,mnv);
            ps.executeUpdate();
            DBconnect.close();
        }
    }
     public Nhanvien updateByID(Nhanvien q) {
        PreparedStatement ps = null;
        if (DBconnect.open()) {
            try {
                ps = DBconnect.cnn.prepareStatement("update tbl_NHANVIEN set TNV = ?,SDT= ?,CMND= ? where  MNV= ?");
                    
                ps.setString(1, q.getTNV());
                ps.setInt(2, q.getSDT());
                ps.setInt(3, q.getCMND());
                ps.setString(4, q.getMNV());
                
                
                int row = ps.executeUpdate();
                if (row < 1) {
                    q = null;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                q = null;
            }finally{
                DBconnect.close();
            }
        }
       return q;
    }
     public ArrayList<Nhanvien> findByMNV(String mnv) {
       ArrayList<Nhanvien> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_NHANVIEN where MNV = ?");
                psCheck.setString(1, mnv);
                rs = psCheck.executeQuery();
                list = new ArrayList<Nhanvien>();
                while (rs.next()) {
                    Nhanvien k = new Nhanvien();
                    k.setMNV(rs.getString(1));
                    k.setTNV(rs.getString(2));
                      k.setSDT(rs.getInt(3));
                        k.setCMND(rs.getInt(4));
                       
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
     public ArrayList<Nhanvien> findByTNV(String tnv) {
       ArrayList<Nhanvien> list = null;
        PreparedStatement psCheck = null;
        ResultSet rs = null;
        if (DBconnect.open()) {
            try {
                psCheck = DBconnect.cnn.prepareStatement("select *from tbl_NHANVIEN where TNV = ?");
                psCheck.setString(1, tnv);
                rs = psCheck.executeQuery();
                list = new ArrayList<Nhanvien>();
                while (rs.next()) {
                    Nhanvien k = new Nhanvien();
                    k.setMNV(rs.getString(1));
                    k.setTNV(rs.getString(2));
                      k.setSDT(rs.getInt(3));
                        k.setCMND(rs.getInt(4));
                       
                    
                    list.add(k);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }finally{
                DBconnect.close(psCheck, rs);
            }
            
        }
        return list;
    }
    
    
}
