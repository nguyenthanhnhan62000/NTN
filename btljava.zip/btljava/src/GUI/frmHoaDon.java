/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import ConnectDataBase.DBconnect;
import Controll.HoadonControll;
import Controll.QuanaoControll;
import Controll.NhanvienControll;
import empty.Tong;
import empty.Hoadon;
import empty.Nhanvien;
import empty.Quanao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.w3c.dom.ls.LSSerializer;



/**
 *
 * @author nhanm
 */
public class frmHoaDon extends javax.swing.JPanel {
    Integer slb = 1;
    LocalDate ngayThangNam = java.time.LocalDate.now();
     
    
    private DefaultTableModel dtm;
    private DefaultComboBoxModel dcbm;
    
    private DefaultTableModel dcb;
    
    private DefaultComboBoxModel CMBNV;
    
    
    
    ArrayList<Nhanvien> allNHaniven = null;
    
    ArrayList<Quanao> alllQuanao = null;
    ArrayList<Quanao> allqa = null;
    ArrayList<Hoadon> list= null;
    ArrayList<Quanao> list_= null;

    /**
     * Creates new form frmHoaDon
     */
    public frmHoaDon() {
        initComponents();
        dtm = new DefaultTableModel();
        dcbm = new DefaultComboBoxModel();
        
        CMBNV = new DefaultComboBoxModel();
        
        dcb  = new DefaultTableModel();
         
//        begin
        alllQuanao = new QuanaoControll().getAll();
        for( Quanao k: alllQuanao){
            dcbm.addElement(k.getMqa());
        }
        comboboxMqa.setModel(dcbm);
        
        
        allNHaniven = new NhanvienControll().getAll();
        for( Nhanvien k: allNHaniven)
        {
            CMBNV.addElement(k.getTNV());
        }
        comboboxNhanvien.setModel(CMBNV);
        
        dtm.addColumn("Mã hóa đơn ");
        dtm.addColumn("Mã quần áo ");
        dtm.addColumn("Loại");  
        dtm.addColumn(" Số lượng ");  
        dtm.addColumn("Thành giá");
        dtm.addColumn("Tên nhân viên");  
        dtm.addColumn("Ngày tháng năm");
    
        loaddata();
            
        ResetForm();      
    }
    private void  loaddata(){
       int sum=0;
       list = new HoadonControll().getAll();
       for (Hoadon khoa : list) {
           dtm.addRow(toObjectsData(khoa));
           sum+=khoa.getThanhgia(); 
       }
       Tong t = new Tong("Tổng tiền bán được($)", sum);
       dtm.addRow(t.toArray());
       jtbdanhmuc.setModel(dtm);      
       
    }
    
      public void reset(){
       
       txtmhd.setText("");
       txtslban.setText(slb.toString());
       txtngaythangnam.setText(ngayThangNam.toString());
       jbnew.setEnabled(true);
       jbdelete.setEnabled(false);
       jbreset.setEnabled(true);
       jbUpdate.setEnabled(false);
       txtmhd.setEnabled(true);
       
   }
      public boolean Check(){
          PreparedStatement ps = null;
          ResultSet rs = null;
          //String mqa = alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa();
          String mqa = null;
          if((alllQuanao.get(comboboxMqa.getSelectedIndex()).getSlton()) != 0)
          {
              mqa = alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa();
              
              if (DBconnect.open()) {
            
              try {
                  ps = DBconnect.cnn.prepareStatement("select *from tbl_QLQA");
                  rs = ps.executeQuery();
                  while (rs.next()) {
                      if( mqa.equals(rs.getString(1).toString()) ){
                           //int slcu=rs.getInt(5);      
                           
                           //int slmoi = slcu-Integer.parseInt(txtslban.getText() );
                           int slmoi = 0;
                           if (!new QuanaoControll().updateslt(mqa,slmoi))
                             return false;  
                      }
                      
                  }                                  
              } catch (SQLException ex) {
                  Logger.getLogger(frmHoaDon.class.getName()).log(Level.SEVERE, null, ex);
              }
              }
        }
        /*if (DBconnect.open()) {
            
              try {
                  ps = DBconnect.cnn.prepareStatement("select *from tbl_QLQA");
                  rs = ps.executeQuery();
                  while (rs.next()) {
                      if( mqa.equals(rs.getString(1).toString()) ){
                           //int slcu=rs.getInt(5);      
                           
                           //int slmoi = slcu-Integer.parseInt(txtslban.getText() );
                           int slmoi = 0;
                           if (!new QuanaoControll().updateslt(mqa,slmoi))
                             return false;  
                      }
                      
                  }                                  
              } catch (SQLException ex) {
                  Logger.getLogger(frmHoaDon.class.getName()).log(Level.SEVERE, null, ex);
              }
        }*/
        return  true;
      }
      
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtmhd = new javax.swing.JTextField();
        txtslban = new javax.swing.JTextField();
        comboboxMqa = new javax.swing.JComboBox<>();
        comboboxNhanvien = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtngaythangnam = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtbdanhmuc = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jbnew = new javax.swing.JButton();
        jbUpdate = new javax.swing.JButton();
        jbdelete = new javax.swing.JButton();
        jbreset = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("QUẢN LÍ HÓA ĐƠN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(408, 408, 408)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Mã hóa đơn");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Mã quần áo");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Nhân viên");

        txtmhd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmhdActionPerformed(evt);
            }
        });

        txtslban.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtslbanActionPerformed(evt);
            }
        });

        comboboxMqa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboboxMqa.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboboxMqaItemStateChanged(evt);
            }
        });
        comboboxMqa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboboxMqaActionPerformed(evt);
            }
        });

        comboboxNhanvien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboboxNhanvien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboboxNhanvienActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Số lượng bán ra");

        jLabel6.setText("Ngày tháng năm");

        jtbdanhmuc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ));
        jtbdanhmuc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbdanhmucMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtbdanhmuc);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addGap(55, 55, 55)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(comboboxMqa, 0, 159, Short.MAX_VALUE)
                    .addComponent(txtmhd, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                    .addComponent(txtngaythangnam))
                .addGap(157, 157, 157)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboboxNhanvien, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(53, 53, 53)
                        .addComponent(txtslban, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(125, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtmhd)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtslban, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboboxMqa, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboboxNhanvien, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtngaythangnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jbnew.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jbnew.setText("Xuất");
        jbnew.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jbnew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbnew.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jbnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnew(evt);
            }
        });

        jbUpdate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jbUpdate.setText("Sửa");
        jbUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jbUpdate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbUpdate.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jbUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbUpdateactionperform(evt);
            }
        });

        jbdelete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jbdelete.setText("Xóa");
        jbdelete.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jbdelete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbdelete.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jbdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbdeleteactionperform(evt);
            }
        });

        jbreset.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jbreset.setText("Làm mới");
        jbreset.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jbreset.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbreset.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jbreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbreset(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("In");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbdelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbnew, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbreset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jbnew, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jbUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jbdelete, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addComponent(jbreset, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(301, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtmhdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmhdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmhdActionPerformed

    private void txtslbanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtslbanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtslbanActionPerformed

   
    private void jbnew(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnew
//        if (!checkinfo()) {
//            return;
//        }
        if((alllQuanao.get(comboboxMqa.getSelectedIndex()).getSlton()) != 0){
        String mhd = txtmhd.getText();
       
        String mqa= alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa();
         
            
        //Integer slban= Integer.parseInt(txtslban.getText());
        Integer slban = 1;

        Integer thanhgia = alllQuanao.get(comboboxMqa.getSelectedIndex()).getGia()*slban;
         
        String mnv=  allNHaniven.get(comboboxNhanvien.getSelectedIndex()).getMNV();
         
        
        LocalDate ngaythangnam = ngayThangNam;
        

        Hoadon k = new Hoadon(mhd, mqa,slban ,thanhgia,mnv, ngaythangnam);
       
            Hoadon insert = new HoadonControll().addNew(k);
            
             if( Check())
                 
             { JOptionPane.showMessageDialog(this, "chạy được ");}
             
                 
            
            
            
            JOptionPane.showMessageDialog(this, "Thêm thành công !", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            if (insert != null) {
                showAll();
            }       
        }
        else
        {
            //System.out.println("Mặt hàng " + alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa() + " đã hết hàng");
            JOptionPane.showMessageDialog(this,"Mặt hàng " + alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa() + " đã hết hàng", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jbnew

    private void jbUpdateactionperform(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbUpdateactionperform
//        if (!checkinfo()) {
//            return;
//        }
    
        String mhd = txtmhd.getText();
        String mqa= alllQuanao.get(comboboxMqa.getSelectedIndex()).getMqa();
        //Integer slban= Integer.parseInt(txtslban.getText());
        Integer slban = 1;
        Integer thanhgia = alllQuanao.get(comboboxMqa.getSelectedIndex()).getGia();
        
        String mnv= allNHaniven.get(comboboxNhanvien.getSelectedIndex()).getMNV();
        LocalDate ngaythangnam = ngayThangNam;
 
        Hoadon q = new Hoadon(mhd, mqa, slban,thanhgia,mnv,ngaythangnam);
        
        Hoadon update = new HoadonControll().updateByID(q);
        
        JOptionPane.showMessageDialog(this, "Sửa thành công !", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        if (update != null) {
            showAll();
        }
        ResetForm();
        jbnew.setEnabled(true);
        jbUpdate.setEnabled(false);
        jbdelete.setEnabled(false);
        txtmhd.setEnabled(true);
        txtngaythangnam.setEditable(true);
        jbreset.setEnabled(true);
        
    }//GEN-LAST:event_jbUpdateactionperform

    private void jbdeleteactionperform(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbdeleteactionperform
        int b = JOptionPane.showConfirmDialog(null, "Bạn chắc chắn muốn xóa dữ liệu này?", "Thông Báo", JOptionPane.YES_NO_OPTION);
        if (b == JOptionPane.YES_OPTION) {
            try {
                String mhd= txtmhd.getText();
                new HoadonControll().deleteHoadon(mhd);
                JOptionPane.showMessageDialog(this, "Xóa thành công !", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Dữ liệu chưa thể xóa", "Thông báo", JOptionPane.ERROR_MESSAGE);
            } 
            while (dtm.getRowCount() > 0) {
                dtm.removeRow(0);
            }

            ResetForm();
            loaddata();
            jbnew.setEnabled(true);
            jbUpdate.setEnabled(false);
            jbdelete.setEnabled(false);
            txtmhd.setEnabled(true);
           
        }
    }//GEN-LAST:event_jbdeleteactionperform

    private void jbreset(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbreset
        ResetForm();
    }//GEN-LAST:event_jbreset

    private void jtbdanhmucMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbdanhmucMouseClicked
        // TODO add your handling code here:
        try {
        txtmhd.setText(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 0).toString());
        comboboxMqa.setSelectedItem(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 1).toString());
        txtslban.setText(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 2).toString()) ;
        comboboxNhanvien.setSelectedItem(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 4).toString());
        txtngaythangnam.setText(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 6).toString());
        
        
//        txttg.setText(jtbdanhmuc.getValueAt(jtbdanhmuc.getSelectedRow(), 3).toString());
        
       jbUpdate.setEnabled(true);
       jbnew.setEnabled(false);   
       jbreset.setEnabled(true);
       jbdelete.setEnabled(true);
     
//        jbNew.setEnabled(false);
//        jbUpdate.setEnabled(true);
//        jbDelete.setEnabled(true);
//        txtMaDM.setEnabled(false);
        } catch (Exception e) {
            System.out.println("Bạn đã chọn sai, vui lòng chọn lại !!");
        }
    }//GEN-LAST:event_jtbdanhmucMouseClicked

    private void comboboxMqaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboboxMqaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboboxMqaActionPerformed

    private void comboboxMqaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboboxMqaItemStateChanged

    }//GEN-LAST:event_comboboxMqaItemStateChanged

    private void comboboxNhanvienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboboxNhanvienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboboxNhanvienActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       String link="src\\GUI\\report1.jrxml";
       try
       {
             String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QLQA";
     String user = "sa"; 
     String pass = "123";
           Connection conn=( Connection) DriverManager .getConnection(url,user,pass);
           JasperReport jr= JasperCompileManager.compileReport(link);   
           
            String mahd = txtmhd.getText();
            HashMap param= new HashMap();
            param.put("MHD", mahd);
           
              JasperPrint jp= JasperFillManager.fillReport(jr,param,conn);
              JasperViewer.viewReport(jp);
            
        }
           catch( Exception ex){
               ex.printStackTrace();
           }
      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void showAll() {
        while (dtm.getRowCount() > 0) {
            dtm.removeRow(0);
        }
      
        
        int sum=0;
        ArrayList<Hoadon> dm = new HoadonControll().getAll();
        for (Hoadon khoa : dm) {
             Vector v = new Vector();
            ArrayList<Quanao> qa=new QuanaoControll().findByMqa(khoa.getMqa());
            ArrayList<Nhanvien> nv = new NhanvienControll().findByMNV(khoa.getMnv());
           
            v.add(khoa.getMhd());
            v.add(qa.get(0).getMqa());
            v.add(qa.get(0).getTheloai());
            v.add(khoa.getSlban());
            v.add(khoa.getThanhgia());
            v.add(nv.get(0).getTNV());
            v.add(khoa.getNgayThangNam());
          
            sum+= khoa.getThanhgia();
            dtm.addRow(v);
        }
            Tong t = new Tong("Tổng tiền bán được ", sum);
            dtm.addRow(t.toArray());
        ResetForm();
    }
    
     private static Object[] toObjectsData(Hoadon hd) {
       ArrayList<Quanao> qa=new QuanaoControll().findByMqa(hd.getMqa());
       ArrayList<Nhanvien> nv= new NhanvienControll().findByMNV(hd.getMnv());
       Object[] objectsdata = {hd.getMhd(),qa.get(0).getMqa(),qa.get(0).getTheloai(),hd.getSlban(),hd.getThanhgia(),nv.get(0).getTNV(),hd.getNgayThangNam()};
       return objectsdata;
    }
    

    private void ResetForm() {
        
        txtmhd.setText("");
        txtslban.setText(slb.toString());
        jbnew.setEnabled(true);

        txtmhd.requestFocus();
       
            list = new HoadonControll().getAll();
         /*Tu dong tang ma truyen len 1*/
                String idCuoiCung=list.get((list.size()-1)).getMhd();
                Integer dem = Integer.parseInt(idCuoiCung.substring(2, idCuoiCung.length()));
                Integer id=dem+1;
                if(id<10){
                    txtmhd.setText("HD"+id.toString());
                }
                else
                txtmhd.setText("HD"+id.toString());
        
    }
    
     
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboboxMqa;
    private javax.swing.JComboBox<String> comboboxNhanvien;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbUpdate;
    private javax.swing.JButton jbdelete;
    private javax.swing.JButton jbnew;
    private javax.swing.JButton jbreset;
    private javax.swing.JTable jtbdanhmuc;
    private javax.swing.JTextField txtmhd;
    private javax.swing.JTextField txtngaythangnam;
    private javax.swing.JTextField txtslban;
    // End of variables declaration//GEN-END:variables

   
}
